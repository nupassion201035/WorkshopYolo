# Anime-detecter > 2025-01-13 9:42am
https://universe.roboflow.com/oggidetectiondataset/anime-detecter

Provided by a Roboflow user
License: CC BY 4.0

